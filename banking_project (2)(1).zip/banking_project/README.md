# Banking Management System (C / TCP sockets)

This is an educational implementation of the CS-513 mini-project specification in the supplied PDF. It provides a TCP client/server architecture, role-based menus, persistent text-file records, concurrent client threads, a one-active-session-per-user rule, and a shared file lock around database operations.

## Files

- `client.c` — interactive client and menus for Customer, Bank Employee, Manager, and Administrator.
- `server.c` — TCP server, authentication, authorization, record management, locking, and persistence.
- `common.h` — protocol constants.
- `Makefile` — build targets.
- `data/` — created by the server at first start; stores users, transaction history, loan applications, and feedback.

## Build

On Linux (e.g. Ubuntu/Fedora), from this directory:

```sh
make
```

Or:

```sh
gcc -std=c11 -Wall -Wextra -Wpedantic -O2 -pthread server.c -o server
gcc -std=c11 -Wall -Wextra -Wpedantic -O2 client.c -o client
```

## Run

Terminal 1:

```sh
./server
```

Terminal 2:

```sh
./client
```

A different server address and port can be supplied:

```sh
./server 5050
./client 127.0.0.1 5050
```

## Demo logins

The server creates these demo accounts only if `data/users.db` is empty/missing:

| Role | Username | Password |
|---|---|---|
| Administrator | `admin` | `admin123` |
| Manager | `manager` | `manager123` |
| Bank Employee | `employee` | `emp123` |
| Customer | `customer` | `cust123` |

Change these demo passwords after logging in. The password values are stored as plaintext to keep the system dependency-free and understandable for a system-software teaching project. This is **not production-grade authentication**.

## Implemented functions

- **Customer:** login, balance inquiry, deposit, withdrawal, transfer to another customer, loan application, password change, feedback, transaction/passbook history, logout/exit.
- **Bank Employee:** add customer, modify customer name, view assigned loans, approve/reject assigned pending loans, view customer passbook, password change, logout/exit.
- **Manager:** activate/deactivate customer accounts, assign pending loans to employees, review feedback, password change, logout/exit.
- **Administrator:** add employees, modify customer/employee names, change non-admin user roles, list users, password change, logout/exit.

## Synchronization and financial ACID design

- Each connected client is served by a detached pthread.
- Database requests use a process-local `pthread_mutex` plus an `fcntl()` write lock on `data/bank.lock`. All server instances must use the same `data/` directory and cooperate with this lock; do not run the server from different working directories against different copies of the data.
- **Money is represented internally as integer cents**, not `double`, so deposits, withdrawals and transfers do not accumulate binary floating-point rounding errors. Inputs must be positive amounts with at most two decimal places and are capped at 1,000,000,000.00 per operation. Account balances are capped at the same value.
- User and transaction files are parsed strictly. Malformed records, duplicate usernames, invalid amounts, non-contiguous transaction IDs, unpaired transfer ledger entries, balance snapshots that do not reconcile, and account balances that disagree with the latest ledger snapshots cause startup or a financial request to fail closed instead of silently skipping bad records.
- **Deposits, withdrawals, transfers, and approved loan disbursements use the undo journal.** The current journal protocol protects `users.db`, `transactions.db`, and `loans.db` as one recoverable transaction. The server prepares durable backups, publishes `txn.journal`, writes and syncs the required files, and then publishes `txn.commit` as the commit point.
- On startup, a journal without a commit marker is rolled back from backups. A valid durable commit marker means the transaction is retained and cleanup is completed. If rollback fails or commit status is uncertain, the running server refuses further requests until restart-time recovery. Do not blindly retry a request after an “uncertain commit” response; check the current balance and transaction history first.
- The ledger is validated before and after financial operations. Transfers require matching debit/credit history rows. Loan approval credits the customer's account and records a `LOAN_CREDIT` passbook entry linked to its loan ID in the same journaled transaction that marks the loan approved. A loan cannot be approved twice and disbursed twice.
- On first startup after upgrading, legacy loans already marked `APPROVED` but lacking a matching `LOAN_CREDIT` history row are credited once through the recovery journal. This migration assumes the previous code marked those loans approved without disbursing the funds. Back up `data/` before upgrading, especially if any loans were manually credited outside the old application.
- `save_users()`, `save_txns()`, and `save_loans()` use temporary files, `fsync()`, atomic `rename()`, and a directory `fsync()` for each file replacement. The version-2 journal wraps the related replacements into a recoverable operation and still supports recovery of legacy version-1 two-file journals.

## Test the financial transaction path

After `make`, run the integration smoke test from the project root:

```sh
make test
```

You can also run it directly with `python3 tests/test_financial_transactions.py`.

The Python test uses temporary data directories. It exercises deposits, withdrawals, transfers, invalid amount handling, concurrent writes, loan application/assignment/approval and balance credit, duplicate-approval prevention, one-time migration of older APPROVED loans that were never disbursed, ledger reconciliation, and interrupted-transaction rollback. It does not modify your project's existing `data/` directory.

## ACID scope and assumptions

For **deposits, withdrawals, transfers, and loan approval/disbursement**, the implementation is designed to provide:

- **Atomicity:** the multi-file balance-and-ledger change is either committed or rolled back during recovery.
- **Consistency:** exact integer-cent arithmetic and ledger/balance invariant checks reject invalid states before commit.
- **Isolation:** the database mutex and advisory file lock serialize cooperating server operations.
- **Durability:** data files, journal files, backups, commit marker, and relevant directory entries are synchronized before success is acknowledged.

These guarantees depend on a local POSIX filesystem honoring `fsync()` and atomic same-filesystem `rename()`, all writers respecting the lock/journal protocol, and no manual edits to data files while the server runs. No custom file-based implementation can guarantee recovery from arbitrary hardware failure, broken storage that lies about flushes, or external tampering. The multi-file journal is scoped to deposits, withdrawals, transfers, and loan approval/disbursement. Loan applications/assignments/rejections that update only `loans.db`, account creation, role changes, password changes, and feedback are still single-file operations or otherwise outside that multi-file protocol. The protocol also has no client-supplied idempotency key, so a client that loses the response after a commit must inspect balance/history before deciding whether to retry.

This remains an educational system-software project rather than production banking software. Passwords are stored in plaintext, there is no TLS, and backup/restore is manual. For real financial use, use a mature transactional database and professional security review.
