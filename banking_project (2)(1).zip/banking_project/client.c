#define _POSIX_C_SOURCE 200809L
#include "common.h"
#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

static int send_all(int fd, const char *buf, size_t len) {
    size_t done=0; while(done<len){ssize_t n=send(fd,buf+done,len-done,0);if(n<0){if(errno==EINTR)continue;return -1;}if(n==0)return -1;done+=(size_t)n;}return 0;
}
static int recv_line(int fd,char *buf,size_t cap){size_t n=0;while(n+1<cap){char c;ssize_t r=recv(fd,&c,1,0);if(r==0)return n? (buf[n]='\0',1):0;if(r<0){if(errno==EINTR)continue;return -1;}if(c=='\n')break;if(c!='\r')buf[n++]=c;}buf[n]='\0';return 1;}
static void input_line(const char *prompt,char *out,size_t cap){
    if(prompt){fputs(prompt,stdout);fflush(stdout);}if(!fgets(out,(int)cap,stdin)){out[0]='\0';return;}
    size_t n=strlen(out);while(n&&(out[n-1]=='\n'||out[n-1]=='\r'))out[--n]='\0';
    for(size_t i=0;i<n;i++)if(out[i]=='|'||out[i]=='\n'||out[i]=='\r')out[i]=' ';
}
static int request(int fd,const char *req,char *resp,size_t cap){
    char wire[PROTO_MAX];int n=snprintf(wire,sizeof(wire),"%s\n",req);if(n<0||(size_t)n>=sizeof(wire)){puts("Request too long.");return -1;}
    if(send_all(fd,wire,(size_t)n)<0){perror("send");return -1;}int r=recv_line(fd,resp,cap);if(r<=0){puts("Server disconnected.");return -1;}return 0;
}
static void show_response(const char *resp){
    const char *message = resp;
    if(!strncmp(resp,"OK|",3)) message = resp + 3;
    else if(!strncmp(resp,"ERR|",4)){ printf("Error: %s\n",resp+4); return; }
    char display[PROTO_MAX]; snprintf(display,sizeof(display),"%s",message);
    for(size_t i=0;display[i];i++) if(display[i]==';') display[i]='\n';
    printf("%s\n",display);
}
static int do_request(int fd,const char *req){char resp[PROTO_MAX];if(request(fd,req,resp,sizeof(resp))<0)return -1;show_response(resp);return !strncmp(resp,"OK|",3)?1:0;}
static void ask_and_send(int fd,const char *cmd,const char *label){
    char a[256],req[PROTO_MAX];input_line(label,a,sizeof(a));
    snprintf(req,sizeof(req),"%s|%s",cmd,a);do_request(fd,req);
}
static void customer_menu(int fd){
    char line[256],req[PROTO_MAX],username[USERNAME_LEN],purpose[256],amount[80];
    while(1){
        puts("\n-- Customer Menu --\n1. View Account Balance\n2. Deposit Money\n3. Withdraw Money\n4. Transfer Funds\n5. Apply for a Loan\n6. Change Password\n7. Add Feedback\n8. View Transaction History\n9. Logout\n10. Exit");input_line("Enter choice: ",line,sizeof(line));
        if(!strcmp(line,"1"))do_request(fd,"BALANCE");
        else if(!strcmp(line,"2")||!strcmp(line,"3")){input_line("Amount: ",amount,sizeof(amount));snprintf(req,sizeof(req),"%s|%s",!strcmp(line,"2")?"DEPOSIT":"WITHDRAW",amount);do_request(fd,req);}
        else if(!strcmp(line,"4")){input_line("Recipient customer username: ",username,sizeof(username));input_line("Amount: ",amount,sizeof(amount));snprintf(req,sizeof(req),"TRANSFER|%s|%s",username,amount);do_request(fd,req);}
        else if(!strcmp(line,"5")){input_line("Loan amount: ",amount,sizeof(amount));input_line("Purpose (one line): ",purpose,sizeof(purpose));snprintf(req,sizeof(req),"LOAN_APPLY|%s|%s",amount,purpose);do_request(fd,req);}
        else if(!strcmp(line,"6")){char oldp[PASSWORD_LEN],newp[PASSWORD_LEN];input_line("Current password: ",oldp,sizeof(oldp));input_line("New password (at least 4 characters): ",newp,sizeof(newp));snprintf(req,sizeof(req),"CHANGE_PASSWORD|%s|%s",oldp,newp);do_request(fd,req);}
        else if(!strcmp(line,"7"))ask_and_send(fd,"FEEDBACK","Feedback: ");
        else if(!strcmp(line,"8"))do_request(fd,"HISTORY");
        else if(!strcmp(line,"9")){do_request(fd,"LOGOUT");return;}
        else if(!strcmp(line,"10")){do_request(fd,"LOGOUT");do_request(fd,"QUIT");exit(0);}
        else puts("Invalid choice. Please select 1-10.");
    }
}
static void employee_menu(int fd){
    char line[256],req[PROTO_MAX],u[USERNAME_LEN],pw[PASSWORD_LEN],name[NAME_LEN],amt[80],id[40],decision[32];
    while(1){puts("\n-- Bank Employee Menu --\n1. Add New Customer\n2. Modify Customer Details\n3. View Assigned Loan Applications\n4. Approve/Reject Assigned Loan\n5. View Customer Transactions (Passbook)\n6. Change Password\n7. Logout\n8. Exit");input_line("Enter choice: ",line,sizeof(line));
        if(!strcmp(line,"1")){input_line("New customer username: ",u,sizeof(u));input_line("Temporary password (4+ characters): ",pw,sizeof(pw));input_line("Customer full name: ",name,sizeof(name));input_line("Initial balance: ",amt,sizeof(amt));snprintf(req,sizeof(req),"ADD_CUSTOMER|%s|%s|%s|%s",u,pw,name,amt);do_request(fd,req);}
        else if(!strcmp(line,"2")){input_line("Customer username: ",u,sizeof(u));input_line("New customer name: ",name,sizeof(name));snprintf(req,sizeof(req),"MODIFY_USER|%s|%s",u,name);do_request(fd,req);}
        else if(!strcmp(line,"3"))do_request(fd,"LOAN_LIST");
        else if(!strcmp(line,"4")){input_line("Loan application ID: ",id,sizeof(id));input_line("Decision (APPROVED or REJECTED): ",decision,sizeof(decision));for(size_t i=0;decision[i];i++)if(decision[i]>='a'&&decision[i]<='z')decision[i]-='a'-'A';snprintf(req,sizeof(req),"LOAN_DECIDE|%s|%s",id,decision);do_request(fd,req);}
        else if(!strcmp(line,"5")){input_line("Customer username: ",u,sizeof(u));snprintf(req,sizeof(req),"CUSTOMER_HISTORY|%s",u);do_request(fd,req);}
        else if(!strcmp(line,"6")){input_line("Current password: ",pw,sizeof(pw));char newp[PASSWORD_LEN];input_line("New password: ",newp,sizeof(newp));snprintf(req,sizeof(req),"CHANGE_PASSWORD|%s|%s",pw,newp);do_request(fd,req);}
        else if(!strcmp(line,"7")){do_request(fd,"LOGOUT");return;}
        else if(!strcmp(line,"8")){do_request(fd,"LOGOUT");do_request(fd,"QUIT");exit(0);}
        else puts("Invalid choice. Please select 1-8.");
    }
}
static void manager_menu(int fd){
    char line[256],req[PROTO_MAX],u[USERNAME_LEN],status[16],id[40],emp[USERNAME_LEN],pw[PASSWORD_LEN],npw[PASSWORD_LEN];
    while(1){puts("\n-- Manager Menu --\n1. Activate/Deactivate Customer Account\n2. Assign Loan Application to Employee\n3. Review Customer Feedback\n4. Change Password\n5. Logout\n6. Exit");input_line("Enter choice: ",line,sizeof(line));
        if(!strcmp(line,"1")){input_line("Customer username: ",u,sizeof(u));input_line("Enter 1 to activate or 0 to deactivate: ",status,sizeof(status));snprintf(req,sizeof(req),"SET_ACTIVE|%s|%s",u,status);do_request(fd,req);}
        else if(!strcmp(line,"2")){input_line("Loan application ID: ",id,sizeof(id));input_line("Employee username: ",emp,sizeof(emp));snprintf(req,sizeof(req),"LOAN_ASSIGN|%s|%s",id,emp);do_request(fd,req);}
        else if(!strcmp(line,"3"))do_request(fd,"FEEDBACK_LIST");
        else if(!strcmp(line,"4")){input_line("Current password: ",pw,sizeof(pw));input_line("New password: ",npw,sizeof(npw));snprintf(req,sizeof(req),"CHANGE_PASSWORD|%s|%s",pw,npw);do_request(fd,req);}
        else if(!strcmp(line,"5")){do_request(fd,"LOGOUT");return;}
        else if(!strcmp(line,"6")){do_request(fd,"LOGOUT");do_request(fd,"QUIT");exit(0);}
        else puts("Invalid choice. Please select 1-6.");
    }
}
static void admin_menu(int fd){
    char line[256],req[PROTO_MAX],u[USERNAME_LEN],pw[PASSWORD_LEN],name[NAME_LEN],role[ROLE_LEN],npw[PASSWORD_LEN];
    while(1){puts("\n-- Administrator Menu --\n1. Add New Bank Employee\n2. Modify Customer/Employee Details\n3. Manage User Roles\n4. List Users\n5. Change Password\n6. Logout\n7. Exit");input_line("Enter choice: ",line,sizeof(line));
        if(!strcmp(line,"1")){input_line("New employee username: ",u,sizeof(u));input_line("Temporary password (4+ characters): ",pw,sizeof(pw));input_line("Employee full name: ",name,sizeof(name));snprintf(req,sizeof(req),"ADD_EMPLOYEE|%s|%s|%s",u,pw,name);do_request(fd,req);}
        else if(!strcmp(line,"2")){input_line("Customer/employee username: ",u,sizeof(u));input_line("New full name: ",name,sizeof(name));snprintf(req,sizeof(req),"MODIFY_USER|%s|%s",u,name);do_request(fd,req);}
        else if(!strcmp(line,"3")){input_line("Username whose role will change: ",u,sizeof(u));input_line("New role (customer, employee, manager): ",role,sizeof(role));snprintf(req,sizeof(req),"SET_ROLE|%s|%s",u,role);do_request(fd,req);}
        else if(!strcmp(line,"4"))do_request(fd,"LIST_USERS");
        else if(!strcmp(line,"5")){input_line("Current password: ",pw,sizeof(pw));input_line("New password: ",npw,sizeof(npw));snprintf(req,sizeof(req),"CHANGE_PASSWORD|%s|%s",pw,npw);do_request(fd,req);}
        else if(!strcmp(line,"6")){do_request(fd,"LOGOUT");return;}
        else if(!strcmp(line,"7")){do_request(fd,"LOGOUT");do_request(fd,"QUIT");exit(0);}
        else puts("Invalid choice. Please select 1-7.");
    }
}
int main(int argc,char **argv){
    const char *ip=argc>1?argv[1]:"127.0.0.1";int port=BANK_PORT;
    if(argc>2){char *end=NULL;long p=strtol(argv[2],&end,10);if(!end||*end||p<1||p>65535){fprintf(stderr,"Usage: %s [server-ip] [port]\n",argv[0]);return EXIT_FAILURE;}port=(int)p;}
    int fd=socket(AF_INET,SOCK_STREAM,0);if(fd<0){perror("socket");return EXIT_FAILURE;}
    struct sockaddr_in addr;memset(&addr,0,sizeof(addr));addr.sin_family=AF_INET;addr.sin_port=htons((unsigned short)port);
    if(inet_pton(AF_INET,ip,&addr.sin_addr)!=1){fprintf(stderr,"Invalid IPv4 address: %s\n",ip);close(fd);return EXIT_FAILURE;}
    if(connect(fd,(struct sockaddr*)&addr,sizeof(addr))<0){perror("connect (start server first)");close(fd);return EXIT_FAILURE;}
    while(1){
        char choice[32],role[ROLE_LEN],user[USERNAME_LEN],pass[PASSWORD_LEN],req[PROTO_MAX],resp[PROTO_MAX];
        puts("\n--Banking Management System--\n\n1. Customer\n2. Bank Employee\n3. Manager\n4. Administrator\n5. Exit");input_line("Enter your choice: ",choice,sizeof(choice));
        if(!strcmp(choice,"5")){request(fd,"QUIT",resp,sizeof(resp));show_response(resp);break;}
        if(!strcmp(choice,"1"))snprintf(role,sizeof(role),"customer");else if(!strcmp(choice,"2"))snprintf(role,sizeof(role),"employee");else if(!strcmp(choice,"3"))snprintf(role,sizeof(role),"manager");else if(!strcmp(choice,"4"))snprintf(role,sizeof(role),"admin");else{puts("Invalid choice.");continue;}
        input_line("Username: ",user,sizeof(user));input_line("Password: ",pass,sizeof(pass));snprintf(req,sizeof(req),"LOGIN|%s|%s|%s",role,user,pass);
        if(request(fd,req,resp,sizeof(resp))<0) break;
        show_response(resp);
        if(strncmp(resp,"OK|",3)) continue;
        if(!strcmp(role,"customer"))customer_menu(fd);else if(!strcmp(role,"employee"))employee_menu(fd);else if(!strcmp(role,"manager"))manager_menu(fd);else admin_menu(fd);
    }
    close(fd);return 0;
}
