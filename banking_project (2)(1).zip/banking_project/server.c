#define _POSIX_C_SOURCE 200809L
#include "common.h"
#include <arpa/inet.h>
#include <errno.h>
#include <limits.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <pthread.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <ctype.h>
#include <unistd.h>

#define MAX_USERS 1000
#define MAX_TXNS 12000
#define MAX_LOANS 3000
#define MAX_FEEDBACK 3000
#define FIELD_COUNT 12
#define MAX_TRANSACTION_CENTS 100000000000LL /* 1,000,000,000.00 */
#define MAX_ACCOUNT_BALANCE_CENTS 100000000000LL

#define USERS_FILE "data/users.db"
#define TXNS_FILE "data/transactions.db"
#define LOANS_FILE "data/loans.db"
#define FEEDBACK_FILE "data/feedback.db"
#define LOCK_FILE "data/bank.lock"
#define JOURNAL_FILE "data/txn.journal"
#define JOURNAL_TMP "data/txn.journal.tmp"
#define COMMIT_FILE "data/txn.commit"
#define COMMIT_TMP "data/txn.commit.tmp"
#define USERS_BACKUP "data/users.db.bak"
#define USERS_BACKUP_TMP "data/users.db.bak.tmp"
#define TXNS_BACKUP "data/transactions.db.bak"
#define TXNS_BACKUP_TMP "data/transactions.db.bak.tmp"
#define USERS_RECOVER_TMP "data/users.db.recover.tmp"
#define TXNS_RECOVER_TMP "data/transactions.db.recover.tmp"
#define LOANS_BACKUP "data/loans.db.bak"
#define LOANS_BACKUP_TMP "data/loans.db.bak.tmp"
#define LOANS_RECOVER_TMP "data/loans.db.recover.tmp"

typedef struct {
    char username[USERNAME_LEN];
    char password[PASSWORD_LEN];
    char role[ROLE_LEN];
    char name[NAME_LEN];
    long long balance_cents;
    int active;
} User;

typedef struct {
    long id;
    char time[32];
    char username[USERNAME_LEN];
    char type[20];
    long long amount_cents;
    char other[USERNAME_LEN];
    long long balance_after_cents;
} Transaction;

typedef struct {
    long id;
    char customer[USERNAME_LEN];
    long long amount_cents;
    char purpose[128];
    char status[20];
    char assigned_to[USERNAME_LEN];
} Loan;

typedef struct {
    long id;
    char time[32];
    char customer[USERNAME_LEN];
    char message[256];
} Feedback;

static pthread_mutex_t db_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t sessions_mutex = PTHREAD_MUTEX_INITIALIZER;
static char active_sessions[MAX_USERS][USERNAME_LEN];
static size_t active_count = 0;
static volatile sig_atomic_t server_running = 1;
/* Set after uncertain commit/failed rollback. Writes are refused until restart recovery. */
static int database_unavailable = 0;

static void trim_newline(char *s) {
    if (!s) return;
    size_t n = strlen(s);
    while (n && (s[n - 1] == '\n' || s[n - 1] == '\r')) s[--n] = '\0';
}

static void set_time(char out[32]) {
    time_t now = time(NULL);
    struct tm tm_now;
    localtime_r(&now, &tm_now);
    strftime(out, 32, "%Y-%m-%d_%H:%M:%S", &tm_now);
}

static int db_begin(void) {
    pthread_mutex_lock(&db_mutex);
    int fd = open(LOCK_FILE, O_CREAT | O_RDWR, 0600);
    if (fd < 0) {
        pthread_mutex_unlock(&db_mutex);
        return -1;
    }
    struct flock lock;
    memset(&lock, 0, sizeof(lock));
    lock.l_type = F_WRLCK;
    lock.l_whence = SEEK_SET;
    while (fcntl(fd, F_SETLKW, &lock) < 0) {
        if (errno == EINTR) continue;
        close(fd);
        pthread_mutex_unlock(&db_mutex);
        return -1;
    }
    return fd;
}

static void db_end(int fd) {
    if (fd >= 0) {
        struct flock lock;
        memset(&lock, 0, sizeof(lock));
        lock.l_type = F_UNLCK;
        lock.l_whence = SEEK_SET;
        (void)fcntl(fd, F_SETLK, &lock);
        close(fd);
    }
    pthread_mutex_unlock(&db_mutex);
}

/* Sync a directory so successful renames/unlinks survive a system crash. */
static int sync_directory_path(const char *path) {
    int fd = open(path, O_RDONLY);
    if (fd < 0) return -1;
    int rc = fsync(fd);
    int saved = errno;
    if (close(fd) != 0 && rc == 0) { rc = -1; saved = errno; }
    errno = saved;
    return rc;
}

static int sync_data_directory(void) {
    return sync_directory_path("data");
}

static int path_exists(const char *path) {
    struct stat st;
    if (lstat(path, &st) == 0) return 1;
    if (errno == ENOENT) return 0;
    return -1;
}

static int unlink_if_exists(const char *path) {
    if (unlink(path) == 0 || errno == ENOENT) return 0;
    return -1;
}

static int write_all(int fd, const void *buffer, size_t length) {
    const char *p = (const char *)buffer;
    size_t done = 0;
    while (done < length) {
        ssize_t n = write(fd, p + done, length - done);
        if (n < 0) { if (errno == EINTR) continue; return -1; }
        if (n == 0) { errno = EIO; return -1; }
        done += (size_t)n;
    }
    return 0;
}

/* Copy a file to a new path and fsync the copied bytes before it is published. */
static int copy_file_durable(const char *source, const char *destination) {
    int in = open(source, O_RDONLY);
    if (in < 0) return -1;
    int out = open(destination, O_WRONLY | O_CREAT | O_TRUNC, 0600);
    if (out < 0) { int e = errno; close(in); errno = e; return -1; }
    char buffer[16384];
    int rc = 0;
    for (;;) {
        ssize_t n = read(in, buffer, sizeof(buffer));
        if (n == 0) break;
        if (n < 0) { if (errno == EINTR) continue; rc = -1; break; }
        if (write_all(out, buffer, (size_t)n) != 0) { rc = -1; break; }
    }
    if (rc == 0 && fsync(out) != 0) rc = -1;
    int saved = errno;
    if (close(in) != 0 && rc == 0) { rc = -1; saved = errno; }
    if (close(out) != 0 && rc == 0) { rc = -1; saved = errno; }
    if (rc != 0) unlink(destination);
    errno = saved;
    return rc;
}

static int publish_text_file(const char *temporary, const char *destination,
                             const char *contents, size_t length) {
    int fd = open(temporary, O_WRONLY | O_CREAT | O_TRUNC, 0600);
    if (fd < 0) return -1;
    int rc = write_all(fd, contents, length);
    if (rc == 0 && fsync(fd) != 0) rc = -1;
    int saved = errno;
    if (close(fd) != 0 && rc == 0) { rc = -1; saved = errno; }
    if (rc != 0) { unlink(temporary); errno = saved; return -1; }
    if (rename(temporary, destination) != 0) { saved = errno; unlink(temporary); errno = saved; return -1; }
    if (sync_data_directory() != 0) return -1;
    return 0;
}

static int split_fields(char *line, char **fields, int max_fields) {
    int n = 0;
    char *save = NULL;
    for (char *p = strtok_r(line, "|", &save); p && n < max_fields;
         p = strtok_r(NULL, "|", &save)) fields[n++] = p;
    return n;
}

/* Money is represented internally as integer cents, never binary floating point. */
static int parse_cents(const char *text, long long *out, int allow_zero,
                       long long maximum_cents) {
    if (!text || !*text || !out || maximum_cents < 0) return -1;
    const unsigned char *p = (const unsigned char *)text;
    unsigned long long whole = 0;
    int whole_digits = 0;
    while (isdigit(*p)) {
        unsigned int digit = (unsigned int)(*p - '0');
        if (whole > (ULLONG_MAX - digit) / 10ULL) return -1;
        whole = whole * 10ULL + digit;
        whole_digits++;
        p++;
    }
    if (whole_digits == 0) return -1;

    unsigned int fraction = 0;
    int fraction_digits = 0;
    if (*p == '.') {
        p++;
        while (isdigit(*p) && fraction_digits < 2) {
            fraction = fraction * 10U + (unsigned int)(*p - '0');
            fraction_digits++;
            p++;
        }
        if (fraction_digits == 0 || isdigit(*p)) return -1;
        if (fraction_digits == 1) fraction *= 10U;
    }
    if (*p != '\0') return -1;
    if (whole > (unsigned long long)(maximum_cents / 100LL)) return -1;
    unsigned long long cents = whole * 100ULL + fraction;
    if (cents > (unsigned long long)maximum_cents) return -1;
    if (!allow_zero && cents == 0ULL) return -1;
    *out = (long long)cents;
    return 0;
}

static int valid_cents(long long cents, int allow_zero, long long maximum_cents) {
    return cents >= (allow_zero ? 0LL : 1LL) && cents <= maximum_cents;
}

static int valid_text_field(const char *s, size_t capacity, int allow_empty) {
    if (!s || strlen(s) >= capacity || (!allow_empty && s[0] == '\0')) return 0;
    return strchr(s, '|') == NULL && strchr(s, '\n') == NULL && strchr(s, '\r') == NULL;
}

static int parse_record_id(const char *s, long *out) {
    if (!s || !*s || !out) return -1;
    errno = 0;
    char *end = NULL;
    long value = strtol(s, &end, 10);
    if (errno == ERANGE || end == s || !end || *end != '\0' || value <= 0) return -1;
    *out = value;
    return 0;
}

static int make_loan_reference(long loan_id, char *out, size_t capacity) {
    if (loan_id <= 0 || !out || capacity == 0) return -1;
    int n = snprintf(out, capacity, "LOAN#%ld", loan_id);
    return n > 0 && (size_t)n < capacity ? 0 : -1;
}

static int parse_loan_reference(const char *text, long *loan_id) {
    if (!text || strncmp(text, "LOAN#", 5) != 0) return -1;
    return parse_record_id(text + 5, loan_id);
}

static int load_users(User users[], int cap) {
    FILE *fp = fopen(USERS_FILE, "r");
    if (!fp) return errno == ENOENT ? 0 : -1;
    char line[512];
    int n = 0;
    int rc = 0;
    while (fgets(line, sizeof(line), fp)) {
        if (n >= cap || (!strchr(line, '\n') && !feof(fp))) { rc = -1; errno = EOVERFLOW; break; }
        trim_newline(line);
        char *f[7];
        if (split_fields(line, f, 7) != 6 ||
            !valid_text_field(f[0], USERNAME_LEN, 0) ||
            !valid_text_field(f[1], PASSWORD_LEN, 0) ||
            !valid_text_field(f[2], ROLE_LEN, 0) ||
            !valid_text_field(f[3], NAME_LEN, 0)) { rc = -1; errno = EINVAL; break; }
        if (strcmp(f[2], "customer") && strcmp(f[2], "employee") &&
            strcmp(f[2], "manager") && strcmp(f[2], "admin")) { rc = -1; errno = EINVAL; break; }
        if (strcmp(f[5], "0") && strcmp(f[5], "1")) { rc = -1; errno = EINVAL; break; }
        long long balance_cents;
        if (parse_cents(f[4], &balance_cents, 1, MAX_ACCOUNT_BALANCE_CENTS) != 0) {
            rc = -1; errno = EINVAL; break;
        }
        for (int i = 0; i < n; i++) {
            if (strcmp(users[i].username, f[0]) == 0) { rc = -1; errno = EINVAL; break; }
        }
        if (rc != 0) break;
        memset(&users[n], 0, sizeof(users[n]));
        snprintf(users[n].username, sizeof(users[n].username), "%s", f[0]);
        snprintf(users[n].password, sizeof(users[n].password), "%s", f[1]);
        snprintf(users[n].role, sizeof(users[n].role), "%s", f[2]);
        snprintf(users[n].name, sizeof(users[n].name), "%s", f[3]);
        users[n].balance_cents = balance_cents;
        users[n].active = (f[5][0] == '1');
        n++;
    }
    if (ferror(fp)) { rc = -1; }
    int close_rc = fclose(fp);
    if (close_rc != 0) rc = -1;
    return rc == 0 ? n : -1;
}

static int save_users(const User users[], int n) {
    const char *tmp = "data/users.db.tmp";
    if (n < 0 || n > MAX_USERS) { errno = EINVAL; return -1; }
    for (int i = 0; i < n; ++i) {
        if (!valid_text_field(users[i].username, USERNAME_LEN, 0) ||
            !valid_text_field(users[i].password, PASSWORD_LEN, 0) ||
            !valid_text_field(users[i].role, ROLE_LEN, 0) ||
            !valid_text_field(users[i].name, NAME_LEN, 0) ||
            !valid_cents(users[i].balance_cents, 1, MAX_ACCOUNT_BALANCE_CENTS) ||
            (users[i].active != 0 && users[i].active != 1)) { errno = EINVAL; return -1; }
        for (int j = 0; j < i; ++j) {
            if (strcmp(users[i].username, users[j].username) == 0) { errno = EINVAL; return -1; }
        }
    }
    FILE *fp = fopen(tmp, "w");
    if (!fp) return -1;
    int rc = 0;
    for (int i = 0; i < n; ++i) {
        if (fprintf(fp, "%s|%s|%s|%s|%lld.%02lld|%d\n", users[i].username,
                    users[i].password, users[i].role, users[i].name,
                    users[i].balance_cents / 100LL, users[i].balance_cents % 100LL,
                    users[i].active) < 0) { rc = -1; break; }
    }
    if (rc == 0 && fflush(fp) != 0) rc = -1;
    if (rc == 0 && fsync(fileno(fp)) != 0) rc = -1;
    int saved = errno;
    if (fclose(fp) != 0 && rc == 0) { rc = -1; saved = errno; }
    if (rc != 0) { unlink(tmp); errno = saved; return -1; }
    if (rename(tmp, USERS_FILE) != 0) { saved = errno; unlink(tmp); errno = saved; return -1; }
    if (sync_data_directory() != 0) return -1;
    return 0;
}

static int load_txns(Transaction rows[], int cap) {
    FILE *fp = fopen(TXNS_FILE, "r");
    if (!fp) return errno == ENOENT ? 0 : -1;
    char line[512];
    int n = 0, rc = 0;
    while (fgets(line, sizeof(line), fp)) {
        if (n >= cap || (!strchr(line, '\n') && !feof(fp))) { rc = -1; errno = EOVERFLOW; break; }
        trim_newline(line);
        char *f[8];
        if (split_fields(line, f, 8) != 7 ||
            !valid_text_field(f[1], sizeof(rows[0].time), 0) ||
            !valid_text_field(f[2], USERNAME_LEN, 0) ||
            !valid_text_field(f[3], sizeof(rows[0].type), 0) ||
            !valid_text_field(f[5], USERNAME_LEN, 0)) { rc = -1; errno = EINVAL; break; }
        long id;
        long long amount_cents, balance_after_cents;
        if (parse_record_id(f[0], &id) != 0 || id == LONG_MAX ||
            (n == 0 && id != 1) ||
            parse_cents(f[4], &amount_cents, 0, MAX_TRANSACTION_CENTS) != 0 ||
            parse_cents(f[6], &balance_after_cents, 1, MAX_ACCOUNT_BALANCE_CENTS) != 0 ||
            (n > 0 && (rows[n - 1].id == LONG_MAX || id != rows[n - 1].id + 1))) {
            rc = -1; errno = EINVAL; break;
        }
        if (strcmp(f[3], "DEPOSIT") && strcmp(f[3], "WITHDRAW") &&
            strcmp(f[3], "TRANSFER_OUT") && strcmp(f[3], "TRANSFER_IN") &&
            strcmp(f[3], "LOAN_CREDIT")) {
            rc = -1; errno = EINVAL; break;
        }
        memset(&rows[n], 0, sizeof(rows[n]));
        rows[n].id = id;
        snprintf(rows[n].time, sizeof(rows[n].time), "%s", f[1]);
        snprintf(rows[n].username, sizeof(rows[n].username), "%s", f[2]);
        snprintf(rows[n].type, sizeof(rows[n].type), "%s", f[3]);
        rows[n].amount_cents = amount_cents;
        snprintf(rows[n].other, sizeof(rows[n].other), "%s", f[5]);
        rows[n].balance_after_cents = balance_after_cents;
        n++;
    }
    if (ferror(fp)) rc = -1;
    if (fclose(fp) != 0) rc = -1;
    return rc == 0 ? n : -1;
}

static int save_txns(const Transaction rows[], int n) {
    const char *tmp = "data/transactions.db.tmp";
    if (n < 0 || n > MAX_TXNS) { errno = EINVAL; return -1; }
    for (int i = 0; i < n; ++i) {
        if (rows[i].id <= 0 ||
            (i > 0 && (rows[i - 1].id == LONG_MAX || rows[i].id != rows[i - 1].id + 1)) ||
            !valid_text_field(rows[i].time, sizeof(rows[i].time), 0) ||
            !valid_text_field(rows[i].username, USERNAME_LEN, 0) ||
            !valid_text_field(rows[i].type, sizeof(rows[i].type), 0) ||
            !valid_text_field(rows[i].other, USERNAME_LEN, 0) ||
            !valid_cents(rows[i].amount_cents, 0, MAX_TRANSACTION_CENTS) ||
            !valid_cents(rows[i].balance_after_cents, 1, MAX_ACCOUNT_BALANCE_CENTS)) {
            errno = EINVAL; return -1;
        }
    }
    FILE *fp = fopen(tmp, "w");
    if (!fp) return -1;
    int rc = 0;
    for (int i = 0; i < n; ++i) {
        if (fprintf(fp, "%ld|%s|%s|%s|%lld.%02lld|%s|%lld.%02lld\n",
                    rows[i].id, rows[i].time, rows[i].username, rows[i].type,
                    rows[i].amount_cents / 100LL, rows[i].amount_cents % 100LL,
                    rows[i].other, rows[i].balance_after_cents / 100LL,
                    rows[i].balance_after_cents % 100LL) < 0) { rc = -1; break; }
    }
    if (rc == 0 && fflush(fp) != 0) rc = -1;
    if (rc == 0 && fsync(fileno(fp)) != 0) rc = -1;
    int saved = errno;
    if (fclose(fp) != 0 && rc == 0) { rc = -1; saved = errno; }
    if (rc != 0) { unlink(tmp); errno = saved; return -1; }
    if (rename(tmp, TXNS_FILE) != 0) { saved = errno; unlink(tmp); errno = saved; return -1; }
    if (sync_data_directory() != 0) return -1;
    return 0;
}


/*
 * Undo-journal protocol for operations that update both users.db and
 * transactions.db. Call only while db_begin()'s lock is held.
 *
 * Ordering:
 *   1. Durable backups, then a durable journal manifest.
 *   2. Replace/sync both data files.
 *   3. Durably publish txn.commit (the commit point).
 *   4. Remove journal first; only then remove the commit marker/backups.
 */
static int restore_original(const char *backup, const char *destination,
                            const char *temporary, int existed) {
    if (!existed) {
        if (unlink_if_exists(destination) != 0) return -1;
        return sync_data_directory();
    }
    if (copy_file_durable(backup, temporary) != 0) return -1;
    if (rename(temporary, destination) != 0) { int e = errno; unlink(temporary); errno = e; return -1; }
    if (sync_data_directory() != 0) return -1;
    return 0;
}

static int valid_commit_marker(void) {
    FILE *fp = fopen(COMMIT_FILE, "r");
    if (!fp) return -1;
    char line[64];
    int valid = fgets(line, sizeof(line), fp) != NULL;
    if (valid) trim_newline(line);
    if (!valid || strcmp(line, "BANKING_COMMIT_V1") != 0 || fgetc(fp) != EOF) valid = 0;
    if (fclose(fp) != 0) valid = 0;
    return valid ? 1 : 0;
}

static int cleanup_journal_files(int keep_commit_marker) {
    /* Remove the journal first and sync that removal before deleting recovery data. */
    if (unlink_if_exists(JOURNAL_FILE) != 0 || sync_data_directory() != 0) return -1;
    const char *paths[] = {
        USERS_BACKUP, TXNS_BACKUP, LOANS_BACKUP,
        USERS_BACKUP_TMP, TXNS_BACKUP_TMP, LOANS_BACKUP_TMP,
        JOURNAL_TMP, USERS_RECOVER_TMP, TXNS_RECOVER_TMP, LOANS_RECOVER_TMP,
        "data/users.db.tmp", "data/transactions.db.tmp", "data/loans.db.tmp", COMMIT_TMP
    };
    for (size_t i = 0; i < sizeof(paths) / sizeof(paths[0]); ++i)
        if (unlink_if_exists(paths[i]) != 0) return -1;
    if (!keep_commit_marker && unlink_if_exists(COMMIT_FILE) != 0) return -1;
    return sync_data_directory();
}

/* Read both the earlier two-file V1 manifest and the current three-file V2 manifest. */
static int parse_journal_manifest(const char *line, int *version,
                                  int *users_existed, int *txns_existed,
                                  int *loans_existed) {
    char extra;
    int u = -1, t = -1, l = -1;
    int parsed = sscanf(line, "BANKING_JOURNAL_V2 %d %d %d %c", &u, &t, &l, &extra);
    if (parsed == 3) {
        *version = 2;
    } else {
        u = -1; t = -1; l = 0;
        parsed = sscanf(line, "BANKING_JOURNAL_V1 %d %d %c", &u, &t, &extra);
        if (parsed != 2) { errno = EINVAL; return -1; }
        *version = 1;
    }
    if ((u != 0 && u != 1) || (t != 0 && t != 1) ||
        (l != 0 && l != 1)) { errno = EINVAL; return -1; }
    *users_existed = u;
    *txns_existed = t;
    *loans_existed = l;
    return 0;
}

/* Recover an existing transaction or remove leftovers from a completed one. */
static int recover_journal_locked(void) {
    int journal_exists = path_exists(JOURNAL_FILE);
    if (journal_exists < 0) return -1;
    if (!journal_exists) {
        /* No published journal means no database file was replaced under it. */
        const char *orphans[] = {
            USERS_BACKUP, TXNS_BACKUP, LOANS_BACKUP,
            USERS_BACKUP_TMP, TXNS_BACKUP_TMP, LOANS_BACKUP_TMP,
            JOURNAL_TMP, USERS_RECOVER_TMP, TXNS_RECOVER_TMP, LOANS_RECOVER_TMP,
            "data/users.db.tmp", "data/transactions.db.tmp", "data/loans.db.tmp",
            COMMIT_TMP, COMMIT_FILE
        };
        for (size_t i = 0; i < sizeof(orphans) / sizeof(orphans[0]); ++i)
            if (unlink_if_exists(orphans[i]) != 0) return -1;
        return sync_data_directory();
    }

    FILE *fp = fopen(JOURNAL_FILE, "r");
    if (!fp) return -1;
    char line[128];
    int nread = fgets(line, sizeof(line), fp) != NULL;
    int trailing = fgetc(fp);
    int close_rc = fclose(fp);
    if (!nread || trailing != EOF || close_rc != 0) { errno = EINVAL; return -1; }

    int version, users_existed, txns_existed, loans_existed;
    if (parse_journal_manifest(line, &version, &users_existed,
                               &txns_existed, &loans_existed) != 0) return -1;

    int commit_exists = path_exists(COMMIT_FILE);
    if (commit_exists < 0) return -1;
    if (commit_exists) {
        int valid = valid_commit_marker();
        if (valid != 1) { errno = EINVAL; return -1; }
        /* A durable commit marker means preserve all committed files. */
        return cleanup_journal_files(0);
    }

    /* No commit marker: restore the original files. This operation is idempotent. */
    if (restore_original(USERS_BACKUP, USERS_FILE, USERS_RECOVER_TMP, users_existed) != 0)
        return -1;
    if (restore_original(TXNS_BACKUP, TXNS_FILE, TXNS_RECOVER_TMP, txns_existed) != 0)
        return -1;
    if (version >= 2 &&
        restore_original(LOANS_BACKUP, LOANS_FILE, LOANS_RECOVER_TMP, loans_existed) != 0)
        return -1;
    return cleanup_journal_files(0);
}

static int journal_begin(void) {
    if (recover_journal_locked() != 0) {
        database_unavailable = 1;
        return -1;
    }

    const char *sources[] = { USERS_FILE, TXNS_FILE, LOANS_FILE };
    const char *backup_tmps[] = { USERS_BACKUP_TMP, TXNS_BACKUP_TMP, LOANS_BACKUP_TMP };
    const char *backups[] = { USERS_BACKUP, TXNS_BACKUP, LOANS_BACKUP };
    int existed[3] = {0, 0, 0};
    for (int i = 0; i < 3; ++i) {
        existed[i] = path_exists(sources[i]);
        if (existed[i] < 0) return -1;
    }
    for (int i = 0; i < 3; ++i) {
        if (!existed[i]) continue;
        if (copy_file_durable(sources[i], backup_tmps[i]) != 0 ||
            rename(backup_tmps[i], backups[i]) != 0) {
            int saved = errno;
            for (int j = 0; j < 3; ++j) {
                (void)unlink_if_exists(backup_tmps[j]);
                (void)unlink_if_exists(backups[j]);
            }
            (void)sync_data_directory();
            errno = saved;
            return -1;
        }
    }
    if (sync_data_directory() != 0) return -1;

    char manifest[80];
    int length = snprintf(manifest, sizeof(manifest), "BANKING_JOURNAL_V2 %d %d %d\n",
                          existed[0], existed[1], existed[2]);
    if (length < 0 || (size_t)length >= sizeof(manifest)) { errno = EINVAL; return -1; }
    if (publish_text_file(JOURNAL_TMP, JOURNAL_FILE, manifest, (size_t)length) != 0) {
        /* The rename may have happened even if directory synchronization failed. */
        int published = path_exists(JOURNAL_FILE);
        if (published == 1) {
            if (recover_journal_locked() != 0) database_unavailable = 1;
        } else if (published == 0) {
            for (int j = 0; j < 3; ++j) {
                (void)unlink_if_exists(backup_tmps[j]);
                (void)unlink_if_exists(backups[j]);
            }
            (void)sync_data_directory();
        } else {
            database_unavailable = 1;
        }
        return -1;
    }
    return 0;
}

static int journal_rollback(void) {
    /* No commit marker should exist before a successful journal_commit(). */
    if (path_exists(COMMIT_FILE) != 0) { errno = EBUSY; return -1; }
    FILE *fp = fopen(JOURNAL_FILE, "r");
    if (!fp) return -1;
    char line[128];
    int nread = fgets(line, sizeof(line), fp) != NULL;
    int trailing = fgetc(fp);
    int close_rc = fclose(fp);
    if (!nread || trailing != EOF || close_rc != 0) { errno = EINVAL; return -1; }
    int version, users_existed, txns_existed, loans_existed;
    if (parse_journal_manifest(line, &version, &users_existed,
                               &txns_existed, &loans_existed) != 0) return -1;
    if (restore_original(USERS_BACKUP, USERS_FILE, USERS_RECOVER_TMP, users_existed) != 0) return -1;
    if (restore_original(TXNS_BACKUP, TXNS_FILE, TXNS_RECOVER_TMP, txns_existed) != 0) return -1;
    if (version >= 2 &&
        restore_original(LOANS_BACKUP, LOANS_FILE, LOANS_RECOVER_TMP, loans_existed) != 0) return -1;
    return cleanup_journal_files(0);
}

static int journal_commit(void) {
    static const char marker[] = "BANKING_COMMIT_V1\n";
    /* save_users/save_txns sync their data file and the data directory. */
    return publish_text_file(COMMIT_TMP, COMMIT_FILE, marker, sizeof(marker) - 1);
}

static int journal_cleanup(void) {
    /* Marker remains until the journal is durably removed. */
    return cleanup_journal_files(0);
}

static int load_loans(Loan rows[], int cap) {
    FILE *fp = fopen(LOANS_FILE, "r");
    if (!fp) return errno == ENOENT ? 0 : -1;
    char line[512]; int n = 0, rc = 0;
    while (fgets(line, sizeof(line), fp)) {
        if (n >= cap || (!strchr(line, '\n') && !feof(fp))) { rc = -1; errno = EOVERFLOW; break; }
        trim_newline(line); char *f[7];
        if (split_fields(line, f, 7) != 6 || !valid_text_field(f[1], USERNAME_LEN, 0) ||
            !valid_text_field(f[3], sizeof(rows[0].purpose), 0) ||
            !valid_text_field(f[4], sizeof(rows[0].status), 0) ||
            !valid_text_field(f[5], USERNAME_LEN, 0)) { rc = -1; errno = EINVAL; break; }
        long id; long long amount_cents;
        if (parse_record_id(f[0], &id) != 0 ||
            parse_cents(f[2], &amount_cents, 0, MAX_TRANSACTION_CENTS) != 0) { rc = -1; errno = EINVAL; break; }
        for (int i = 0; i < n; ++i) if (rows[i].id == id) { rc = -1; errno = EINVAL; break; }
        if (rc != 0) break;
        memset(&rows[n], 0, sizeof(rows[n])); rows[n].id = id;
        snprintf(rows[n].customer, sizeof(rows[n].customer), "%s", f[1]); rows[n].amount_cents = amount_cents;
        snprintf(rows[n].purpose, sizeof(rows[n].purpose), "%s", f[3]);
        snprintf(rows[n].status, sizeof(rows[n].status), "%s", f[4]);
        snprintf(rows[n].assigned_to, sizeof(rows[n].assigned_to), "%s", f[5]); n++;
    }
    if (ferror(fp)) rc = -1;
    if (fclose(fp) != 0) rc = -1;
    return rc == 0 ? n : -1;
}

static int save_loans(const Loan rows[], int n) {
    const char *tmp = "data/loans.db.tmp";
    if (n < 0 || n > MAX_LOANS) { errno = EINVAL; return -1; }
    FILE *fp = fopen(tmp, "w");
    if (!fp) return -1;
    int rc = 0;
    for (int i = 0; i < n; ++i) {
        if (!valid_cents(rows[i].amount_cents, 0, MAX_TRANSACTION_CENTS) ||
            fprintf(fp, "%ld|%s|%lld.%02lld|%s|%s|%s\n", rows[i].id, rows[i].customer,
                    rows[i].amount_cents / 100LL, rows[i].amount_cents % 100LL,
                    rows[i].purpose, rows[i].status, rows[i].assigned_to) < 0) { rc = -1; break; }
    }
    if (rc == 0 && fflush(fp) != 0) rc = -1;
    if (rc == 0 && fsync(fileno(fp)) != 0) rc = -1;
    int saved = errno;
    if (fclose(fp) != 0 && rc == 0) { rc = -1; saved = errno; }
    if (rc != 0) { unlink(tmp); errno = saved; return -1; }
    if (rename(tmp, LOANS_FILE) != 0) { saved = errno; unlink(tmp); errno = saved; return -1; }
    if (sync_data_directory() != 0) return -1;
    return 0;
}


static int load_feedback(Feedback rows[], int cap) {
    FILE *fp = fopen(FEEDBACK_FILE, "r"); if (!fp) return 0;
    char line[512]; int n = 0;
    while (n < cap && fgets(line, sizeof(line), fp)) {
        trim_newline(line); char *f[4];
        if (split_fields(line, f, 4) != 4) continue;
        rows[n].id = atol(f[0]); snprintf(rows[n].time, sizeof(rows[n].time), "%s", f[1]);
        snprintf(rows[n].customer, sizeof(rows[n].customer), "%s", f[2]);
        snprintf(rows[n].message, sizeof(rows[n].message), "%s", f[3]); n++;
    }
    fclose(fp); return n;
}

static int save_feedback(const Feedback rows[], int n) {
    const char *tmp = "data/feedback.db.tmp";
    FILE *fp = fopen(tmp, "w");
    if (!fp) return -1;
    for (int i = 0; i < n; ++i) {
        if (fprintf(fp, "%ld|%s|%s|%s\n", rows[i].id, rows[i].time,
                    rows[i].customer, rows[i].message) < 0) {
            fclose(fp); unlink(tmp); return -1;
        }
    }
    if (fflush(fp) != 0 || fsync(fileno(fp)) != 0) {
        int e = errno; fclose(fp); unlink(tmp); errno = e; return -1;
    }
    if (fclose(fp) != 0) { int e = errno; unlink(tmp); errno = e; return -1; }
    if (rename(tmp, FEEDBACK_FILE) != 0) { int e = errno; unlink(tmp); errno = e; return -1; }
    if (sync_data_directory() != 0) return -1;
    return 0;
}

static int find_user(const User users[], int n, const char *username) {
    for (int i = 0; i < n; ++i) if (strcmp(users[i].username, username) == 0) return i;
    return -1;
}

static int is_role(const char *actual, const char *required) { return strcmp(actual, required) == 0; }

/*
 * Validate the ledger before a financial write. Replays each account's money
 * movements in order, checks transfer pairs, and requires the most recent
 * ledger balance to equal the account file balance.
 */
static int validate_financial_state(User users[], int nu, Transaction tx[], int nt) {
    if (nu < 0 || nu > MAX_USERS || nt < 0 || nt > MAX_TXNS) return -1;
    long long last_balance[MAX_USERS];
    unsigned char has_balance[MAX_USERS];
    memset(last_balance, 0, sizeof(last_balance));
    memset(has_balance, 0, sizeof(has_balance));

    for (int i = 0; i < nt; ++i) {
        int owner = find_user(users, nu, tx[i].username);
        /* Historical accounts can have a changed role; preserve their ledger. */
        if (owner < 0 ||
            !valid_cents(tx[i].amount_cents, 0, MAX_TRANSACTION_CENTS) ||
            !valid_cents(tx[i].balance_after_cents, 1, MAX_ACCOUNT_BALANCE_CENTS)) return -1;

        long long amount = tx[i].amount_cents;
        long long after = tx[i].balance_after_cents;
        long long expected = 0;
        int seen = has_balance[owner] != 0;

        if (!strcmp(tx[i].type, "DEPOSIT") || !strcmp(tx[i].type, "LOAN_CREDIT")) {
            if (!strcmp(tx[i].type, "DEPOSIT")) {
                if (strcmp(tx[i].other, "-") != 0) return -1;
            } else {
                long referenced_loan_id;
                if (parse_loan_reference(tx[i].other, &referenced_loan_id) != 0) return -1;
            }
            if (seen) {
                if (amount > MAX_ACCOUNT_BALANCE_CENTS - last_balance[owner]) return -1;
                expected = last_balance[owner] + amount;
                if (after != expected) return -1;
            } else if (after < amount) {
                return -1; /* Implied opening balance would be negative. */
            }
        } else if (!strcmp(tx[i].type, "WITHDRAW")) {
            if (strcmp(tx[i].other, "-") != 0) return -1;
            if (seen) {
                if (last_balance[owner] < amount) return -1;
                expected = last_balance[owner] - amount;
                if (after != expected) return -1;
            } else if (amount > MAX_ACCOUNT_BALANCE_CENTS - after) {
                return -1; /* Implied opening balance would exceed the limit. */
            }
        } else if (!strcmp(tx[i].type, "TRANSFER_OUT")) {
            if (i + 1 >= nt || strcmp(tx[i + 1].type, "TRANSFER_IN") != 0 ||
                tx[i].id == LONG_MAX || tx[i + 1].id != tx[i].id + 1 ||
                tx[i].amount_cents != tx[i + 1].amount_cents ||
                strcmp(tx[i].username, tx[i + 1].other) != 0 ||
                strcmp(tx[i].other, tx[i + 1].username) != 0 ||
                !strcmp(tx[i].username, tx[i].other)) return -1;
            if (seen) {
                if (last_balance[owner] < amount) return -1;
                expected = last_balance[owner] - amount;
                if (after != expected) return -1;
            } else if (amount > MAX_ACCOUNT_BALANCE_CENTS - after) {
                return -1;
            }
        } else if (!strcmp(tx[i].type, "TRANSFER_IN")) {
            if (i == 0 || strcmp(tx[i - 1].type, "TRANSFER_OUT") != 0 ||
                tx[i - 1].id == LONG_MAX || tx[i].id != tx[i - 1].id + 1 ||
                tx[i].amount_cents != tx[i - 1].amount_cents ||
                strcmp(tx[i].username, tx[i - 1].other) != 0 ||
                strcmp(tx[i].other, tx[i - 1].username) != 0) return -1;
            if (seen) {
                if (amount > MAX_ACCOUNT_BALANCE_CENTS - last_balance[owner]) return -1;
                expected = last_balance[owner] + amount;
                if (after != expected) return -1;
            } else if (after < amount) {
                return -1;
            }
        } else {
            return -1;
        }

        last_balance[owner] = after;
        has_balance[owner] = 1;
    }

    for (int u = 0; u < nu; ++u) {
        if (!valid_cents(users[u].balance_cents, 1, MAX_ACCOUNT_BALANCE_CENTS)) return -1;
        if (has_balance[u] && last_balance[u] != users[u].balance_cents) return -1;
    }
    return 0;
}

static int add_transaction(Transaction rows[], int *n, long id, const char *username,
                           const char *type, long long amount_cents,
                           const char *other, long long balance_cents) {
    if (*n >= MAX_TXNS || id <= 0 ||
        !valid_cents(amount_cents, 0, MAX_TRANSACTION_CENTS) ||
        !valid_cents(balance_cents, 1, MAX_ACCOUNT_BALANCE_CENTS)) return -1;
    Transaction *t = &rows[(*n)++]; memset(t, 0, sizeof(*t)); t->id = id; set_time(t->time);
    snprintf(t->username, sizeof(t->username), "%s", username); snprintf(t->type, sizeof(t->type), "%s", type);
    t->amount_cents = amount_cents; snprintf(t->other, sizeof(t->other), "%s", other ? other : "-");
    t->balance_after_cents = balance_cents;
    return 0;
}

static void respond(int fd, const char *fmt, ...) {
    char out[PROTO_MAX]; va_list ap; va_start(ap, fmt); vsnprintf(out, sizeof(out), fmt, ap); va_end(ap);
    size_t len = strlen(out); if (len + 1 >= sizeof(out)) len = sizeof(out) - 2;
    out[len++] = '\n';
    size_t sent = 0;
    while (sent < len) { ssize_t k = send(fd, out + sent, len - sent, MSG_NOSIGNAL); if (k <= 0) break; sent += (size_t)k; }
}

static int recv_line(int fd, char *buf, size_t cap) {
    size_t n = 0;
    while (n + 1 < cap) {
        char c; ssize_t r = recv(fd, &c, 1, 0);
        if (r == 0) return n == 0 ? 0 : (buf[n] = '\0', 1);
        if (r < 0) { if (errno == EINTR) continue; return -1; }
        if (c == '\n') break;
        if (c != '\r') buf[n++] = c;
    }
    buf[n] = '\0'; return 1;
}

static int session_add(const char *username) {
    int ok = 0; pthread_mutex_lock(&sessions_mutex);
    for (size_t i = 0; i < active_count; ++i) if (!strcmp(active_sessions[i], username)) { pthread_mutex_unlock(&sessions_mutex); return 0; }
    if (active_count < MAX_USERS) { snprintf(active_sessions[active_count++], USERNAME_LEN, "%s", username); ok = 1; }
    pthread_mutex_unlock(&sessions_mutex); return ok;
}

static void session_remove(const char *username) {
    pthread_mutex_lock(&sessions_mutex);
    for (size_t i = 0; i < active_count; ++i) if (!strcmp(active_sessions[i], username)) {
        if (i + 1 < active_count) memmove(active_sessions[i], active_sessions[i + 1], (active_count - i - 1) * sizeof(active_sessions[0]));
        active_count--; break;
    }
    pthread_mutex_unlock(&sessions_mutex);
}

static int find_loan_index(const Loan loans[], int nl, long loan_id) {
    for (int i = 0; i < nl; ++i) if (loans[i].id == loan_id) return i;
    return -1;
}

static int count_loan_credit(const Transaction tx[], int nt, long loan_id,
                             int *record_index) {
    char reference[USERNAME_LEN];
    if (make_loan_reference(loan_id, reference, sizeof(reference)) != 0) return -1;
    int count = 0;
    if (record_index) *record_index = -1;
    for (int i = 0; i < nt; ++i) {
        if (!strcmp(tx[i].type, "LOAN_CREDIT") && !strcmp(tx[i].other, reference)) {
            count++;
            if (record_index) *record_index = i;
        }
    }
    return count;
}

/*
 * Verify the relation between loan statuses and ledger credits. When
 * allow_missing_approved is true, legacy APPROVED rows without a LOAN_CREDIT
 * are permitted temporarily so startup can migrate them safely.
 */
static int validate_loan_ledger(const User users[], int nu,
                                const Loan loans[], int nl,
                                const Transaction tx[], int nt,
                                int allow_missing_approved) {
    if (nu < 0 || nl < 0 || nt < 0) return -1;
    for (int i = 0; i < nl; ++i) {
        const Loan *loan = &loans[i];
        if (find_user(users, nu, loan->customer) < 0 ||
            !valid_cents(loan->amount_cents, 0, MAX_TRANSACTION_CENTS) ||
            (strcmp(loan->status, "PENDING") && strcmp(loan->status, "APPROVED") &&
             strcmp(loan->status, "REJECTED"))) return -1;
        int credit_index = -1;
        int count = count_loan_credit(tx, nt, loan->id, &credit_index);
        if (count < 0 || count > 1) return -1;
        if (!strcmp(loan->status, "APPROVED")) {
            if (count == 0) {
                if (!allow_missing_approved) return -1;
            } else {
                const Transaction *credit = &tx[credit_index];
                if (strcmp(credit->username, loan->customer) != 0 ||
                    credit->amount_cents != loan->amount_cents) return -1;
            }
        } else if (count != 0) {
            return -1;
        }
    }
    for (int i = 0; i < nt; ++i) {
        if (strcmp(tx[i].type, "LOAN_CREDIT") == 0) {
            long loan_id;
            if (parse_loan_reference(tx[i].other, &loan_id) != 0) return -1;
            int ix = find_loan_index(loans, nl, loan_id);
            if (ix < 0 || strcmp(loans[ix].status, "APPROVED") != 0 ||
                strcmp(tx[i].username, loans[ix].customer) != 0 ||
                tx[i].amount_cents != loans[ix].amount_cents) return -1;
        }
    }
    return 0;
}

/*
 * The previous server marked loans APPROVED but did not disburse them. On
 * startup, credit each such legacy approval once, identified by absence of its
 * unique LOAN_CREDIT ledger reference. The three-file journal makes migration
 * crash-recoverable and prevents partial updates.
 */
static int migrate_legacy_approved_loans_locked(User users[], int nu,
                                                 Loan loans[], int nl,
                                                 Transaction tx[], int *nt_ptr) {
    int nt = *nt_ptr;
    if (validate_financial_state(users, nu, tx, nt) != 0 ||
        validate_loan_ledger(users, nu, loans, nl, tx, nt, 1) != 0) return -1;

    int changed = 0;
    for (int i = 0; i < nl; ++i) {
        if (strcmp(loans[i].status, "APPROVED") != 0) continue;
        int credit_index = -1;
        int credits = count_loan_credit(tx, nt, loans[i].id, &credit_index);
        if (credits < 0 || credits > 1) return -1;
        if (credits == 1) continue;

        int customer_index = find_user(users, nu, loans[i].customer);
        if (customer_index < 0 || !valid_cents(users[customer_index].balance_cents,
                                               1, MAX_ACCOUNT_BALANCE_CENTS) ||
            loans[i].amount_cents > MAX_ACCOUNT_BALANCE_CENTS - users[customer_index].balance_cents ||
            nt >= MAX_TXNS) return -1;
        long next_id = nt ? tx[nt - 1].id + 1 : 1;
        if (next_id <= 0 || (nt && tx[nt - 1].id == LONG_MAX)) return -1;
        char reference[USERNAME_LEN];
        if (make_loan_reference(loans[i].id, reference, sizeof(reference)) != 0) return -1;
        long long new_balance = users[customer_index].balance_cents + loans[i].amount_cents;
        if (add_transaction(tx, &nt, next_id, loans[i].customer, "LOAN_CREDIT",
                            loans[i].amount_cents, reference, new_balance) != 0) return -1;
        users[customer_index].balance_cents = new_balance;
        changed = 1;
    }

    if (!changed) {
        *nt_ptr = nt;
        return validate_loan_ledger(users, nu, loans, nl, tx, nt, 0);
    }
    if (validate_financial_state(users, nu, tx, nt) != 0 ||
        validate_loan_ledger(users, nu, loans, nl, tx, nt, 0) != 0) return -1;

    if (journal_begin() != 0) return -1;
    if (save_users(users, nu) != 0 || save_txns(tx, nt) != 0) {
        if (journal_rollback() != 0) database_unavailable = 1;
        return -1;
    }
    if (journal_commit() != 0) {
        database_unavailable = 1;
        return -1;
    }
    (void)journal_cleanup();
    *nt_ptr = nt;
    return 0;
}

static void seed_database(void) {
    int created_data_dir = 0;
    if (mkdir("data", 0700) == 0) created_data_dir = 1;
    else if (errno != EEXIST) { perror("mkdir data"); exit(EXIT_FAILURE); }
    if (created_data_dir && sync_directory_path(".") != 0) {
        perror("sync parent directory for data"); exit(EXIT_FAILURE);
    }
    int lock = db_begin(); if (lock < 0) { perror("database lock"); exit(EXIT_FAILURE); }
    if (recover_journal_locked() != 0) {
        perror("database journal recovery failed; refusing to start");
        db_end(lock);
        exit(EXIT_FAILURE);
    }
    User users[MAX_USERS]; int n = load_users(users, MAX_USERS);
    if (n < 0) {
        perror("users database is invalid or unreadable; refusing to start");
        db_end(lock);
        exit(EXIT_FAILURE);
    }
    if (n == 0) {
        memset(users, 0, sizeof(users));
        snprintf(users[0].username, sizeof(users[0].username), "admin"); snprintf(users[0].password, sizeof(users[0].password), "admin123"); snprintf(users[0].role, sizeof(users[0].role), "admin"); snprintf(users[0].name, sizeof(users[0].name), "System Administrator"); users[0].active = 1;
        snprintf(users[1].username, sizeof(users[1].username), "manager"); snprintf(users[1].password, sizeof(users[1].password), "manager123"); snprintf(users[1].role, sizeof(users[1].role), "manager"); snprintf(users[1].name, sizeof(users[1].name), "Bank Manager"); users[1].active = 1;
        snprintf(users[2].username, sizeof(users[2].username), "employee"); snprintf(users[2].password, sizeof(users[2].password), "emp123"); snprintf(users[2].role, sizeof(users[2].role), "employee"); snprintf(users[2].name, sizeof(users[2].name), "Bank Employee"); users[2].active = 1;
        snprintf(users[3].username, sizeof(users[3].username), "customer"); snprintf(users[3].password, sizeof(users[3].password), "cust123"); snprintf(users[3].role, sizeof(users[3].role), "customer"); snprintf(users[3].name, sizeof(users[3].name), "Sample Customer"); users[3].balance_cents = 100000; users[3].active = 1;
        if (save_users(users, 4) != 0) {
            perror("could not create seed users"); db_end(lock); exit(EXIT_FAILURE);
        }
        n = load_users(users, MAX_USERS);
        if (n != 4) { perror("could not verify seed users"); db_end(lock); exit(EXIT_FAILURE); }
    }
    Transaction tx[MAX_TXNS]; int nt = load_txns(tx, MAX_TXNS);
    Loan loans[MAX_LOANS]; int nl = load_loans(loans, MAX_LOANS);
    if (nt < 0 || nl < 0 || validate_financial_state(users, n, tx, nt) != 0 ||
        validate_loan_ledger(users, n, loans, nl, tx, nt, 1) != 0) {
        fprintf(stderr, "Financial/loan data consistency check failed; refusing to start. Restore a known-good backup.\n");
        db_end(lock);
        exit(EXIT_FAILURE);
    }
    if (migrate_legacy_approved_loans_locked(users, n, loans, nl, tx, &nt) != 0 ||
        validate_financial_state(users, n, tx, nt) != 0 ||
        validate_loan_ledger(users, n, loans, nl, tx, nt, 0) != 0) {
        fprintf(stderr, "Loan disbursement migration or consistency check failed; refusing to start.\n");
        db_end(lock);
        exit(EXIT_FAILURE);
    }
    db_end(lock);
}

static int require_role(const char *actual, const char *expected) { return strcmp(actual, expected) == 0; }

/* Every command is one line. Fields are separated by |; clients must not send | in fields. */
static void process_request(int fd, char *line, char *session_user, char *session_role) {
    char *f[8]; int nf = split_fields(line, f, 8);
    if (nf < 1) { respond(fd, "ERR|Empty request."); return; }
    const char *cmd = f[0];

    if (!strcmp(cmd, "PING")) { respond(fd, "OK|Server is running."); return; }
    if (!strcmp(cmd, "LOGIN")) {
        if (session_user[0]) { respond(fd, "ERR|A session is already logged in on this connection."); return; }
        if (nf != 4) { respond(fd, "ERR|Usage: LOGIN|role|username|password"); return; }
        char role[ROLE_LEN]; snprintf(role, sizeof(role), "%s", f[1]);
        if (strcmp(role,"customer") && strcmp(role,"employee") && strcmp(role,"manager") && strcmp(role,"admin")) { respond(fd,"ERR|Invalid role."); return; }
        int lock = db_begin(); if (lock < 0) { respond(fd,"ERR|Database lock failed."); return; }
        if (database_unavailable) { db_end(lock); respond(fd, "ERR|Database recovery required; restart the server."); return; }
        User users[MAX_USERS]; int n = load_users(users, MAX_USERS);
        if (n < 0) { database_unavailable = 1; db_end(lock); respond(fd, "ERR|Users database failed integrity validation."); return; }
        int i = find_user(users,n,f[2]);
        int valid = i >= 0 && users[i].active && !strcmp(users[i].password,f[3]) && !strcmp(users[i].role,role);
        db_end(lock);
        if (!valid) { respond(fd, "ERR|Invalid credentials, role, or inactive account."); return; }
        if (!session_add(f[2])) { respond(fd, "ERR|This user already has an active session."); return; }
        snprintf(session_user, USERNAME_LEN, "%s", f[2]); snprintf(session_role, ROLE_LEN, "%s", role);
        respond(fd, "OK|Login successful. Welcome, %s.", f[2]); return;
    }
    if (!strcmp(cmd, "LOGOUT")) {
        if (session_user[0]) session_remove(session_user);
        session_user[0] = '\0'; session_role[0] = '\0'; respond(fd, "OK|Logged out."); return;
    }
    if (!strcmp(cmd, "QUIT")) { respond(fd,"OK|Goodbye."); return; }
    if (!session_user[0]) { respond(fd, "ERR|Please log in first."); return; }

    int lock = db_begin();
    if (lock < 0) { respond(fd, "ERR|Could not lock the database."); return; }
    if (database_unavailable) { db_end(lock); respond(fd, "ERR|Database recovery required; restart the server."); return; }
    User users[MAX_USERS]; int nu = load_users(users, MAX_USERS);
    if (nu < 0) { database_unavailable = 1; db_end(lock); respond(fd, "ERR|Users database failed integrity validation."); return; }
    int me = find_user(users, nu, session_user);
    if (me < 0 || !users[me].active || strcmp(users[me].role, session_role)) {
        db_end(lock); respond(fd, "ERR|Your account is unavailable. Log in again.");
        session_remove(session_user); session_user[0] = '\0'; session_role[0] = '\0'; return;
    }

    if (!strcmp(cmd, "BALANCE")) {
        if (!require_role(session_role,"customer")) { db_end(lock); respond(fd,"ERR|Customers only."); return; }
        long long b = users[me].balance_cents;
        db_end(lock); respond(fd,"OK|Current balance: %lld.%02lld", b / 100LL, b % 100LL); return;
    }
    if (!strcmp(cmd,"DEPOSIT") || !strcmp(cmd,"WITHDRAW")) {
        if (!require_role(session_role,"customer") || nf != 2) { db_end(lock); respond(fd,"ERR|Invalid operation or role."); return; }
        long long amount_cents;
        if (parse_cents(f[1], &amount_cents, 0, MAX_TRANSACTION_CENTS) != 0) {
            db_end(lock); respond(fd,"ERR|Enter a positive amount with at most two decimal places."); return;
        }
        if (!valid_cents(users[me].balance_cents, 1, MAX_ACCOUNT_BALANCE_CENTS)) {
            database_unavailable = 1; db_end(lock); respond(fd,"ERR|Account balance failed integrity validation."); return;
        }
        long long new_balance = users[me].balance_cents;
        if (!strcmp(cmd,"WITHDRAW")) {
            if (new_balance < amount_cents) { db_end(lock); respond(fd,"ERR|Insufficient balance."); return; }
            new_balance -= amount_cents;
        } else {
            if (amount_cents > MAX_ACCOUNT_BALANCE_CENTS - new_balance) {
                db_end(lock); respond(fd,"ERR|Deposit would exceed the maximum account balance."); return;
            }
            new_balance += amount_cents;
        }

        Transaction tx[MAX_TXNS]; int nt = load_txns(tx, MAX_TXNS);
        if (nt < 0 || validate_financial_state(users, nu, tx, nt) != 0) {
            database_unavailable = 1; db_end(lock); respond(fd,"ERR|Transaction history failed integrity validation."); return;
        }
        if (nt >= MAX_TXNS - 1) { db_end(lock); respond(fd,"ERR|Transaction history is full."); return; }
        long next_id = nt ? tx[nt - 1].id + 1 : 1;
        if (next_id <= 0 || add_transaction(tx, &nt, next_id, session_user, cmd,
                                            amount_cents, "-", new_balance) != 0) {
            db_end(lock); respond(fd,"ERR|Could not prepare transaction."); return;
        }
        /* Check the proposed balance and ledger together before touching disk. */
        users[me].balance_cents = new_balance;
        if (validate_financial_state(users, nu, tx, nt) != 0) {
            db_end(lock); respond(fd,"ERR|Proposed transaction violates financial consistency rules."); return;
        }
        if (journal_begin() != 0) {
            db_end(lock); respond(fd,"ERR|Could not prepare recovery journal; no transaction was applied."); return;
        }
        if (save_users(users,nu) != 0 || save_txns(tx,nt) != 0) {
            if (journal_rollback() != 0) {
                database_unavailable = 1;
                db_end(lock); respond(fd,"ERR|Write failed and rollback failed; restart required for recovery."); return;
            }
            db_end(lock); respond(fd,"ERR|Transaction failed and was rolled back."); return;
        }
        if (journal_commit() != 0) {
            database_unavailable = 1;
            db_end(lock); respond(fd,"ERR|Commit status is uncertain; restart required for recovery. Check balance before retrying."); return;
        }
        (void)journal_cleanup();
        long long b = users[me].balance_cents; db_end(lock);
        respond(fd,"OK|%s successful. New balance: %lld.%02lld",cmd,b / 100LL,b % 100LL); return;
    }
    if (!strcmp(cmd,"TRANSFER")) {
        if (!require_role(session_role,"customer") || nf != 3) { db_end(lock); respond(fd,"ERR|Invalid operation or role."); return; }
        long long amount_cents;
        int to = find_user(users,nu,f[1]);
        if (parse_cents(f[2], &amount_cents, 0, MAX_TRANSACTION_CENTS) != 0 ||
            to < 0 || !is_role(users[to].role,"customer") || !users[to].active || to == me) {
            db_end(lock); respond(fd,"ERR|Invalid recipient or amount."); return;
        }
        if (!valid_cents(users[me].balance_cents, 1, MAX_ACCOUNT_BALANCE_CENTS) ||
            !valid_cents(users[to].balance_cents, 1, MAX_ACCOUNT_BALANCE_CENTS)) {
            database_unavailable = 1; db_end(lock); respond(fd,"ERR|Account balance failed integrity validation."); return;
        }
        if (users[me].balance_cents < amount_cents) { db_end(lock); respond(fd,"ERR|Insufficient balance."); return; }
        if (amount_cents > MAX_ACCOUNT_BALANCE_CENTS - users[to].balance_cents) {
            db_end(lock); respond(fd,"ERR|Transfer would exceed recipient balance limit."); return;
        }
        Transaction tx[MAX_TXNS]; int nt = load_txns(tx,MAX_TXNS);
        if (nt < 0 || validate_financial_state(users, nu, tx, nt) != 0) {
            database_unavailable = 1; db_end(lock); respond(fd,"ERR|Transaction history failed integrity validation."); return;
        }
        if (nt >= MAX_TXNS-2 || (nt > 0 && tx[nt-1].id >= LONG_MAX - 1)) {
            db_end(lock); respond(fd,"ERR|Transaction history is full."); return;
        }
        long id = (nt ? tx[nt-1].id : 0) + 1;
        long long sender_balance = users[me].balance_cents - amount_cents;
        long long recipient_balance = users[to].balance_cents + amount_cents;
        if (add_transaction(tx,&nt,id,session_user,"TRANSFER_OUT",amount_cents,users[to].username,sender_balance) != 0 ||
            add_transaction(tx,&nt,id+1,users[to].username,"TRANSFER_IN",amount_cents,session_user,recipient_balance) != 0) {
            db_end(lock); respond(fd,"ERR|Could not prepare transfer history."); return;
        }
        users[me].balance_cents = sender_balance;
        users[to].balance_cents = recipient_balance;
        if (validate_financial_state(users, nu, tx, nt) != 0) {
            db_end(lock); respond(fd,"ERR|Proposed transfer violates financial consistency rules."); return;
        }
        if (journal_begin() != 0) {
            db_end(lock); respond(fd,"ERR|Could not prepare recovery journal; transfer was not applied."); return;
        }
        if (save_users(users,nu) != 0 || save_txns(tx,nt) != 0) {
            if (journal_rollback() != 0) {
                database_unavailable = 1;
                db_end(lock); respond(fd,"ERR|Transfer write failed and rollback failed; restart required for recovery."); return;
            }
            db_end(lock); respond(fd,"ERR|Transfer failed and was rolled back."); return;
        }
        if (journal_commit() != 0) {
            database_unavailable = 1;
            db_end(lock); respond(fd,"ERR|Transfer commit status is uncertain; restart required for recovery. Check both balances before retrying."); return;
        }
        (void)journal_cleanup();
        long long b=users[me].balance_cents; db_end(lock);
        respond(fd,"OK|Transfer successful. New balance: %lld.%02lld",b / 100LL,b % 100LL); return;
    }
    if (!strcmp(cmd,"HISTORY") || !strcmp(cmd,"CUSTOMER_HISTORY")) {
        int target_field = !strcmp(cmd,"HISTORY") ? -1 : 1;
        const char *target = target_field < 0 ? session_user : (nf >= 2 ? f[1] : "");
        if (target_field >= 0 && !(require_role(session_role,"employee") || require_role(session_role,"manager") || require_role(session_role,"admin"))) { db_end(lock); respond(fd,"ERR|Only bank staff may view another customer's passbook."); return; }
        if (find_user(users,nu,target) < 0 || !is_role(users[find_user(users,nu,target)].role,"customer")) { db_end(lock); respond(fd,"ERR|Customer not found."); return; }
        Transaction tx[MAX_TXNS]; int nt=load_txns(tx,MAX_TXNS); if (nt < 0) { database_unavailable = 1; db_end(lock); respond(fd,"ERR|Transaction history failed integrity validation."); return; } char body[PROTO_MAX-64]; size_t used=0;
        for (int i=0;i<nt;i++) if (!strcmp(tx[i].username,target)) {
            char item[256]; snprintf(item,sizeof(item),"#%ld %s %s %lld.%02lld (other: %s, balance: %lld.%02lld); ",tx[i].id,tx[i].time,tx[i].type,tx[i].amount_cents/100LL,tx[i].amount_cents%100LL,tx[i].other,tx[i].balance_after_cents/100LL,tx[i].balance_after_cents%100LL);
            size_t z=strlen(item); if (used+z+1>=sizeof(body)) break; memcpy(body+used,item,z); used+=z;
        }
        if (!used) snprintf(body,sizeof(body),"No transactions found."); else body[used]='\0';
        db_end(lock); respond(fd,"OK|Passbook for %s: %s",target,body); return;
    }
    if (!strcmp(cmd,"LOAN_APPLY")) {
        if (!require_role(session_role,"customer") || nf != 3) { db_end(lock); respond(fd,"ERR|Invalid operation or role."); return; }
        long long amount_cents; if (parse_cents(f[1], &amount_cents, 0, MAX_TRANSACTION_CENTS) != 0) { db_end(lock); respond(fd,"ERR|Enter a valid loan amount with at most two decimal places."); return; }
        Loan loans[MAX_LOANS]; int nl=load_loans(loans,MAX_LOANS); if(nl < 0) { db_end(lock); respond(fd,"ERR|Loan database failed integrity validation."); return; } if(nl>=MAX_LOANS) { db_end(lock); respond(fd,"ERR|Loan application limit reached."); return; }
        if (nl < 0) { db_end(lock); respond(fd,"ERR|Loan database failed integrity validation."); return; } Loan *l=&loans[nl]; memset(l,0,sizeof(*l)); l->id=(nl?loans[nl-1].id:0)+1; snprintf(l->customer,sizeof(l->customer),"%s",session_user); l->amount_cents=amount_cents; snprintf(l->purpose,sizeof(l->purpose),"%s",f[2]); snprintf(l->status,sizeof(l->status),"PENDING"); snprintf(l->assigned_to,sizeof(l->assigned_to),"-");
        if(save_loans(loans,nl+1)){db_end(lock);respond(fd,"ERR|Could not save loan application.");return;} long id=l->id; db_end(lock); respond(fd,"OK|Loan application submitted. Application ID: %ld",id); return;
    }
    if (!strcmp(cmd,"LOAN_LIST")) {
        if (!(require_role(session_role,"employee") || require_role(session_role,"manager") || require_role(session_role,"admin"))) { db_end(lock); respond(fd,"ERR|Bank staff only."); return; }
        Loan loans[MAX_LOANS]; int nl=load_loans(loans,MAX_LOANS); if(nl < 0) { db_end(lock); respond(fd,"ERR|Loan database failed integrity validation."); return; } char body[PROTO_MAX-64]; size_t used=0;
        for(int i=0;i<nl;i++) {
            if (require_role(session_role,"employee") && strcmp(loans[i].assigned_to,session_user)) continue;
            char item[300]; snprintf(item,sizeof(item),"ID %ld, customer %s, amount %lld.%02lld, purpose %.120s, status %s, assigned %s; ",loans[i].id,loans[i].customer,loans[i].amount_cents/100LL,loans[i].amount_cents%100LL,loans[i].purpose,loans[i].status,loans[i].assigned_to);
            size_t z=strlen(item); if(used+z+1>=sizeof(body))break; memcpy(body+used,item,z);used+=z;
        }
        if(!used)snprintf(body,sizeof(body),"No matching loan applications.");else body[used]='\0'; db_end(lock); respond(fd,"OK|Loan applications: %s",body);return;
    }
    if (!strcmp(cmd, "LOAN_DECIDE")) {
        if (!require_role(session_role, "employee") || nf != 3 ||
            (strcmp(f[2], "APPROVED") && strcmp(f[2], "REJECTED"))) {
            db_end(lock);
            respond(fd, "ERR|Usage: loan ID and APPROVED or REJECTED (employees only).");
            return;
        }

        long id;
        if (parse_record_id(f[1], &id) != 0) {
            db_end(lock); respond(fd, "ERR|Invalid loan application ID."); return;
        }
        Loan loans[MAX_LOANS];
        int nl = load_loans(loans, MAX_LOANS);
        if (nl < 0) { db_end(lock); respond(fd, "ERR|Loan database failed integrity validation."); return; }
        int ix = find_loan_index(loans, nl, id);
        if (ix < 0 || strcmp(loans[ix].assigned_to, session_user) != 0 ||
            strcmp(loans[ix].status, "PENDING") != 0) {
            db_end(lock);
            respond(fd, "ERR|Loan not found, not assigned to you, or already processed.");
            return;
        }

        if (strcmp(f[2], "REJECTED") == 0) {
            snprintf(loans[ix].status, sizeof(loans[ix].status), "REJECTED");
            if (save_loans(loans, nl) != 0) {
                db_end(lock); respond(fd, "ERR|Could not save loan rejection."); return;
            }
            db_end(lock); respond(fd, "OK|Loan %ld marked REJECTED. No funds were disbursed.", id); return;
        }

        int customer_index = find_user(users, nu, loans[ix].customer);
        if (customer_index < 0 || strcmp(users[customer_index].role, "customer") != 0) {
            db_end(lock); respond(fd, "ERR|Loan applicant is not a valid customer account."); return;
        }
        if (!valid_cents(users[customer_index].balance_cents, 1, MAX_ACCOUNT_BALANCE_CENTS)) {
            database_unavailable = 1;
            db_end(lock); respond(fd, "ERR|Customer balance failed integrity validation."); return;
        }
        if (loans[ix].amount_cents > MAX_ACCOUNT_BALANCE_CENTS - users[customer_index].balance_cents) {
            db_end(lock); respond(fd, "ERR|Loan would exceed the maximum customer balance."); return;
        }

        Transaction tx[MAX_TXNS];
        int nt = load_txns(tx, MAX_TXNS);
        if (nt < 0 || validate_financial_state(users, nu, tx, nt) != 0 ||
            validate_loan_ledger(users, nu, loans, nl, tx, nt, 0) != 0) {
            database_unavailable = 1;
            db_end(lock); respond(fd, "ERR|Financial or loan ledger failed integrity validation."); return;
        }
        if (nt >= MAX_TXNS || (nt > 0 && tx[nt - 1].id == LONG_MAX)) {
            db_end(lock); respond(fd, "ERR|Transaction history is full."); return;
        }
        int existing_credit = count_loan_credit(tx, nt, id, NULL);
        if (existing_credit != 0) {
            database_unavailable = 1;
            db_end(lock); respond(fd, "ERR|Loan credit already exists or ledger is inconsistent; recovery required."); return;
        }

        char reference[USERNAME_LEN];
        if (make_loan_reference(id, reference, sizeof(reference)) != 0) {
            db_end(lock); respond(fd, "ERR|Could not create loan transaction reference."); return;
        }
        long next_transaction_id = nt ? tx[nt - 1].id + 1 : 1;
        long long new_balance = users[customer_index].balance_cents + loans[ix].amount_cents;
        if (add_transaction(tx, &nt, next_transaction_id, loans[ix].customer,
                            "LOAN_CREDIT", loans[ix].amount_cents, reference,
                            new_balance) != 0) {
            db_end(lock); respond(fd, "ERR|Could not prepare loan disbursement transaction."); return;
        }
        users[customer_index].balance_cents = new_balance;
        snprintf(loans[ix].status, sizeof(loans[ix].status), "APPROVED");

        if (validate_financial_state(users, nu, tx, nt) != 0 ||
            validate_loan_ledger(users, nu, loans, nl, tx, nt, 0) != 0) {
            db_end(lock); respond(fd, "ERR|Loan disbursement violates financial consistency rules."); return;
        }
        if (journal_begin() != 0) {
            db_end(lock); respond(fd, "ERR|Could not prepare recovery journal; loan was not approved."); return;
        }
        if (save_users(users, nu) != 0 || save_txns(tx, nt) != 0 || save_loans(loans, nl) != 0) {
            if (journal_rollback() != 0) {
                database_unavailable = 1;
                db_end(lock); respond(fd, "ERR|Loan disbursement failed and rollback failed; restart required for recovery."); return;
            }
            db_end(lock); respond(fd, "ERR|Loan disbursement failed and was rolled back."); return;
        }
        if (journal_commit() != 0) {
            database_unavailable = 1;
            db_end(lock); respond(fd, "ERR|Loan commit status is uncertain; restart required for recovery. Check balance before retrying."); return;
        }
        (void)journal_cleanup();
        long long credited_balance = users[customer_index].balance_cents;
        long long credited_amount = loans[ix].amount_cents;
        char credited_customer[USERNAME_LEN];
        snprintf(credited_customer, sizeof(credited_customer), "%s", loans[ix].customer);
        db_end(lock);
        respond(fd, "OK|Loan %ld APPROVED. Credited %s with %lld.%02lld; new balance: %lld.%02lld.",
                id, credited_customer, credited_amount / 100LL, credited_amount % 100LL,
                credited_balance / 100LL, credited_balance % 100LL);
        return;
    }
    if (!strcmp(cmd,"LOAN_ASSIGN")) {
        if (!require_role(session_role,"manager") || nf!=3){db_end(lock);respond(fd,"ERR|Manager only. Usage: loan ID and employee username.");return;}
        int ei=find_user(users,nu,f[2]); Loan loans[MAX_LOANS]; int nl=load_loans(loans,MAX_LOANS); if(nl < 0) { db_end(lock); respond(fd,"ERR|Loan database failed integrity validation."); return; } long id=atol(f[1]); int ix=-1;
        for(int i=0;i<nl;i++)if(loans[i].id==id){ix=i;break;}
        if(ei<0 || !is_role(users[ei].role,"employee") || !users[ei].active || ix<0 || strcmp(loans[ix].status,"PENDING")){db_end(lock);respond(fd,"ERR|Active employee or pending loan not found.");return;}
        snprintf(loans[ix].assigned_to,sizeof(loans[ix].assigned_to),"%s",f[2]); if(save_loans(loans,nl)){db_end(lock);respond(fd,"ERR|Could not assign loan.");return;} db_end(lock);respond(fd,"OK|Loan %ld assigned to %s.",id,f[2]);return;
    }
    if (!strcmp(cmd,"FEEDBACK")) {
        if (!require_role(session_role,"customer") || nf!=2){db_end(lock);respond(fd,"ERR|Customers only; include feedback text.");return;}
        Feedback rows[MAX_FEEDBACK]; int n=load_feedback(rows,MAX_FEEDBACK); if(n>=MAX_FEEDBACK){db_end(lock);respond(fd,"ERR|Feedback limit reached.");return;}
        Feedback *b=&rows[n]; memset(b,0,sizeof(*b)); b->id=(n?rows[n-1].id:0)+1; set_time(b->time); snprintf(b->customer,sizeof(b->customer),"%s",session_user); snprintf(b->message,sizeof(b->message),"%s",f[1]);
        if(save_feedback(rows,n+1)){db_end(lock);respond(fd,"ERR|Could not save feedback.");return;}long id=b->id;db_end(lock);respond(fd,"OK|Feedback submitted. Reference ID: %ld",id);return;
    }
    if (!strcmp(cmd,"FEEDBACK_LIST")) {
        if (!require_role(session_role,"manager") && !require_role(session_role,"admin")){db_end(lock);respond(fd,"ERR|Managers or administrators only.");return;}
        Feedback rows[MAX_FEEDBACK];int n=load_feedback(rows,MAX_FEEDBACK);char body[PROTO_MAX-64];size_t used=0;
        for(int i=0;i<n;i++){char item[320];snprintf(item,sizeof(item),"ID %ld, %s, %s: %s; ",rows[i].id,rows[i].time,rows[i].customer,rows[i].message);size_t z=strlen(item);if(used+z+1>=sizeof(body))break;memcpy(body+used,item,z);used+=z;}
        if(!used)snprintf(body,sizeof(body),"No feedback received.");else body[used]='\0';db_end(lock);respond(fd,"OK|Customer feedback: %s",body);return;
    }
    if (!strcmp(cmd,"CHANGE_PASSWORD")) {
        if(nf!=3 || strcmp(users[me].password,f[1]) || strlen(f[2])<4){db_end(lock);respond(fd,"ERR|Old password is wrong or new password has fewer than 4 characters.");return;}
        snprintf(users[me].password,sizeof(users[me].password),"%s",f[2]);int result=save_users(users,nu);db_end(lock);if(result)respond(fd,"ERR|Could not change password.");else respond(fd,"OK|Password changed.");return;
    }
    if (!strcmp(cmd,"ADD_CUSTOMER") || !strcmp(cmd,"ADD_EMPLOYEE")) {
        int add_customer=!strcmp(cmd,"ADD_CUSTOMER");
        if ((add_customer && !require_role(session_role,"employee")) || (!add_customer && !require_role(session_role,"admin"))) {db_end(lock);respond(fd,"ERR|You do not have permission for this operation.");return;}
        if ((add_customer && nf!=5) || (!add_customer && nf!=4) || nu>=MAX_USERS || find_user(users,nu,f[1])>=0 || strlen(f[2])<4) {db_end(lock);respond(fd,"ERR|Invalid fields, duplicate username, capacity reached, or password too short.");return;}
        long long initial_cents=0;
        if(add_customer && parse_cents(f[4], &initial_cents, 1, MAX_ACCOUNT_BALANCE_CENTS) != 0){db_end(lock);respond(fd,"ERR|Invalid initial balance.");return;}
        User *u=&users[nu];memset(u,0,sizeof(*u));snprintf(u->username,sizeof(u->username),"%s",f[1]);snprintf(u->password,sizeof(u->password),"%s",f[2]);snprintf(u->role,sizeof(u->role),"%s",add_customer?"customer":"employee");snprintf(u->name,sizeof(u->name),"%s",f[3]);u->balance_cents=initial_cents;u->active=1;
        if(save_users(users,nu+1)){db_end(lock);respond(fd,"ERR|Could not create user.");return;}db_end(lock);respond(fd,"OK|%s %s created successfully.",add_customer?"Customer":"Employee",f[1]);return;
    }
    if (!strcmp(cmd,"MODIFY_USER")) {
        if (!(require_role(session_role,"employee") || require_role(session_role,"admin")) || nf!=3) {db_end(lock);respond(fd,"ERR|Employee or admin only. Include username and new name.");return;}
        int ix=find_user(users,nu,f[1]); if(ix<0 || !(is_role(users[ix].role,"customer") || (require_role(session_role,"admin") && is_role(users[ix].role,"employee")))) {db_end(lock);respond(fd,"ERR|Customer/employee not found or not permitted.");return;}
        snprintf(users[ix].name,sizeof(users[ix].name),"%s",f[2]);if(save_users(users,nu)){db_end(lock);respond(fd,"ERR|Could not modify details.");return;}db_end(lock);respond(fd,"OK|Details updated for %s.",f[1]);return;
    }
    if (!strcmp(cmd,"SET_ACTIVE")) {
        if(!require_role(session_role,"manager") || nf!=3 || (strcmp(f[2],"0")&&strcmp(f[2],"1"))){db_end(lock);respond(fd,"ERR|Manager only. Use username and 1 (activate) or 0 (deactivate).");return;}
        int ix=find_user(users,nu,f[1]);if(ix<0 || !is_role(users[ix].role,"customer")){db_end(lock);respond(fd,"ERR|Customer not found.");return;}
        users[ix].active=atoi(f[2]);if(save_users(users,nu)){db_end(lock);respond(fd,"ERR|Could not update account status.");return;}db_end(lock);respond(fd,"OK|Customer %s is now %s.",f[1],users[ix].active?"active":"inactive");return;
    }
    if (!strcmp(cmd,"SET_ROLE")) {
        if(!require_role(session_role,"admin") || nf!=3 || (strcmp(f[2],"customer")&&strcmp(f[2],"employee")&&strcmp(f[2],"manager"))){db_end(lock);respond(fd,"ERR|Admin only. Role must be customer, employee, or manager.");return;}
        int ix=find_user(users,nu,f[1]);if(ix<0 || !strcmp(users[ix].role,"admin")){db_end(lock);respond(fd,"ERR|User not found or administrator role cannot be changed here.");return;}
        snprintf(users[ix].role,sizeof(users[ix].role),"%s",f[2]);if(save_users(users,nu)){db_end(lock);respond(fd,"ERR|Could not change user role.");return;}db_end(lock);respond(fd,"OK|Role for %s changed to %s.",f[1],f[2]);return;
    }
    if (!strcmp(cmd,"LIST_USERS")) {
        if(!require_role(session_role,"admin")){db_end(lock);respond(fd,"ERR|Administrator only.");return;}
        char body[PROTO_MAX-64];size_t used=0;
        for(int i=0;i<nu;i++){char item[160];snprintf(item,sizeof(item),"%.31s (%.15s, %.63s, %s); ",users[i].username,users[i].role,users[i].name,users[i].active?"active":"inactive");size_t z=strlen(item);if(used+z+1>=sizeof(body))break;memcpy(body+used,item,z);used+=z;}
        if(!used)snprintf(body,sizeof(body),"No users.");else body[used]='\0';db_end(lock);respond(fd,"OK|Users: %s",body);return;
    }
    db_end(lock);
    respond(fd, "ERR|Unknown command.");
}

static void *client_thread(void *arg) {
    int fd = *(int *)arg; free(arg);
    char session_user[USERNAME_LEN] = "", session_role[ROLE_LEN] = "";
    char line[PROTO_MAX];
    while (server_running) {
        int rc = recv_line(fd, line, sizeof(line));
        if (rc <= 0) break;
        char copy[PROTO_MAX]; snprintf(copy,sizeof(copy),"%s",line);
        process_request(fd,copy,session_user,session_role);
        if (!strcmp(line,"QUIT")) break;
    }
    if(session_user[0])session_remove(session_user);
    close(fd); return NULL;
}

static void handle_signal(int sig) { (void)sig; server_running = 0; }

int main(int argc, char **argv) {
    int port = BANK_PORT;
    if(argc>1){char *end=NULL;long p=strtol(argv[1],&end,10);if(!end||*end||p<1||p>65535){fprintf(stderr,"Usage: %s [port]\n",argv[0]);return EXIT_FAILURE;}port=(int)p;}
    signal(SIGINT,handle_signal); signal(SIGTERM,handle_signal); signal(SIGPIPE,SIG_IGN);
    seed_database();
    int server_fd=socket(AF_INET,SOCK_STREAM,0);if(server_fd<0){perror("socket");return EXIT_FAILURE;}
    int opt=1;setsockopt(server_fd,SOL_SOCKET,SO_REUSEADDR,&opt,sizeof(opt));
    struct sockaddr_in addr;memset(&addr,0,sizeof(addr));addr.sin_family=AF_INET;addr.sin_addr.s_addr=htonl(INADDR_ANY);addr.sin_port=htons((unsigned short)port);
    if(bind(server_fd,(struct sockaddr*)&addr,sizeof(addr))<0){perror("bind");close(server_fd);return EXIT_FAILURE;}
    if(listen(server_fd,32)<0){perror("listen");close(server_fd);return EXIT_FAILURE;}
    printf("Banking server listening on port %d\n",port);printf("Demo accounts (change passwords after login): admin/admin123, manager/manager123, employee/emp123, customer/cust123\n");fflush(stdout);
    while(server_running){
        struct sockaddr_in peer;socklen_t plen=sizeof(peer);int cfd=accept(server_fd,(struct sockaddr*)&peer,&plen);
        if(cfd<0){if(errno==EINTR)continue;if(!server_running)break;perror("accept");continue;}
        int *arg=malloc(sizeof(*arg));if(!arg){close(cfd);continue;}*arg=cfd;
        pthread_t tid;if(pthread_create(&tid,NULL,client_thread,arg)!=0){perror("pthread_create");close(cfd);free(arg);continue;}pthread_detach(tid);
    }
    close(server_fd);pthread_mutex_destroy(&db_mutex);pthread_mutex_destroy(&sessions_mutex);puts("Server stopped.");return 0;
}
