#ifndef BANKING_COMMON_H
#define BANKING_COMMON_H

#define BANK_PORT 5050
#define PROTO_MAX 8192
#define USERNAME_LEN 32
#define PASSWORD_LEN 64
#define NAME_LEN 64
#define ROLE_LEN 16

#endif
